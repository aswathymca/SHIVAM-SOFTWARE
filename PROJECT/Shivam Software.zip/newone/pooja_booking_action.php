<?php
include("connection.php");

$name=$_POST['Name'];
$phone=$_POST['phonem'];
$age=$_POST['Age'];
$address=$_POST['Address'];
$pooja=$_POST['pooja'];
$nakshathra=$_POST['nakshathra'];
$dob=$_POST['date'];
$amount=$_POST['amount'];
$status='0';
//$log="select * from login where Email='$email' and status='approved'";
$log="select registration_id from new_registration where Name='$name',Age='$age',$Address='$address',$phonem='$phone'";
$result = $conn->query($log);
$row1=mysqli_fetch_array($result);
$rid=$row1['registration_id'];
$log1="select nakshathra_id from addnakshathra where nakshathra='$nakshathra'";
$result1 = $conn->query($log1);
$row2=mysqli_fetch_array($result1);
$rid1=$row2['nakshathra_id'];
$log2="select addpooja_id from addpooja where pooja='$pooja'";
$result2 = $conn->query($log2);
$row3=mysqli_fetch_array($result2);
$rid2=$row3['addpooja_id'];




if ($result->num_rows != 0) {


$sql = "INSERT INTO pooja_booking(datebook,status,addpooja_id,nakshathra_id,registration_id )values('$date',$status,$rid2,$rid1,$rid,)";

if ($conn->query($sql) === TRUE) {
	
	
	echo" <script>
	alert('success');
	window.location='poojabooking.php';</script>";
} else {


echo" <script>
	alert('failed!! please try again');
	window.location='poojabooking.php';</script>";
}

}
else
{
	?>
	<script>
	 alert("error");
	</script>
	<?php
	header("location: new_registration.php");

}

?>