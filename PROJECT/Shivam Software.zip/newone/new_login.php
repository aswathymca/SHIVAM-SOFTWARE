﻿<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- Bootsrap, CSS file -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" href="styles.css">
 <link rel="stylesheet" href="login1.css">
 
  <!-- Javascript and jQuery files -->
  
  
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  

  
   <!-- page title -->
   <title>Shivam</title>
    <!-- Internal css -->
	<style>
	
	.bg
	{
	background-color:lightgrey;
	background-repeat: no-repeat;
   background-size: cover;
    background-image:url("banner.jpg");
   	
	}
	
	 .logo
	{
   
	float:left;
    width: 16%;
    height:8%;
	
	}
	
	
	.slider_image_holder{
    width: 100%;
    height: 30%;
	margin-top:1%;
	margin-bottom:10%;
	border:2px solid black;
	
    }
	.contents
	{
	width: 100%;
    height: 100%;
	
	
	border:2px solid black;
	}
	.foot
	{
	
	margin-bottom:0%;
	}
	</style>
	
	
	<!-- internal javascrpt code -->
   <script>
   
   $('.message a').click(function(){
   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
});
   
		function loginValid(mail,passwrd)

		{
                    	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
			var passw=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
			
		   if(mail.value.match(mailformat))
			{
				
				//document.login.email.focus();
				if(passwrd.value.match(passw)) 
					{ 
			
					//window.location="succ_login.php";
					//window.location="succes_login.php";
					
					return true;
	
					}
					else
					{ 
				
					alert('Please enter a valid password...! Your password should be 8 to 20 characters which contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character');
					
					window.location="new_login.php";
					
					}
			}
		  else
			{
			alert("Please enter a valid Email-id and password !");
			document.login.email.focus();
			
			}


		}
	</script>
   </head>
   
   <body class="bg">
   
   <!-- starting header navigation -->
   <div class="row">
   <div class="col-lg-12">
	<div class="navbar navbar-inverse navbar-fixed-top">
	
	<div class="container">
	
	
	<button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse" >
	<span class="icon-bar"></span">
	<span class="icon-bar"></span">
	<span class="icon-bar"></span">
	
	</button>
			
	<div class="collapse navbar-collapse navHeaderCollapse">
	
		<ul class="nav navbar-nav navbar-right">
			<li><h4><a href="index.php">Home</a></h4>
			</li>
			
			
			
			
			
			<li ><h4><a href="new_login.php" >&nbsp;&nbsp;Login</a></h4></li>
			<li class="active"><h4><a href="new_registration.php">&nbsp;&nbsp;Registration</a></h4></li>
				
			
		</ul>
	</div>
	
	</div>
		</div>
		<!-- Ending header navigation -->
		
		</div>
		</div>
	
		<center>
<div class="row">
<div class="col-lg-12 logincontainer">

  <form   action="slogaction.php" class="container1" name="Login" id="Login" method="POST">

    <h2>Login</h2>

    
   <input type="email"  autocomplete="off" placeholder="Email Id" name="mail" id="mail" class="input input1 form-control" required>

        <input type="password" placeholder="Enter Password " class="input input1 form-control" name="password" id="password" required>

	
    <input type="submit" name="submit" value="Login"  class="buttonlogin login-hover-color"/>
		<a href="forgot2.php"><h3>Forgot Password?</h3></a>


  </form>
</div>
</div>
</center>
		
   <!-- Ending body content-->
  
  

		
		
   </body>
   </html>
   
	