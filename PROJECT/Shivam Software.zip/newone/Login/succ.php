

<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- Bootsrap, CSS file -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" href=" styles.css">
 
  <!-- Javascript and jQuery files -->
  
  
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
   <!-- page title -->
   <title>Dreams</title>
    <!-- Internal css -->
	<style>
	
	.bg
	{
	background-color:lightgrey;

   background-size: cover;
   background-image:url("back1.jpg");
   	
	}
	
	 .logo
	{
   
	float:left;
    width: 16%;
    height:8%;
	
	}
	
	
	.bodycontent{
	position:relative;
   
	margin-top:10%;
	margin-left:3%;
	margin-right:3%;
	max-width:100%;
	background-color:white;
	padding:3%;
	border:1px solid grey;
	border-radius:5% 7%;
	box-shadow: 10px 5px 5px black;
	
    }
	.contents
	{
	width: 100%;
    height: 100%;
	
	
	border:2px solid black;
	}
	
	</style>
	
	
	<!-- internal javascrpt code -->
   
   </head>
   
   <body class="bg">
   
			
			<!-- starting header navigation -->
   <div class="row">
   <div class="col-lg-12">
	<div class="navbar navbar-inverse navbar-fixed-top">
	
	<div class="container">
	
	<a href="home.html" class="navbar-brand">DREAMS!
		</a>
	<button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse" >
	<span class="icon-bar"></span">
	<span class="icon-bar"></span">
	<span class="icon-bar"></span">
	
	</button>
			
	<div class="collapse navbar-collapse navHeaderCollapse">
	
		<ul class="nav navbar-nav navbar-right">
			<li class="active"> <a  href="myprofile.php">Profile</a></li>
			<li> <a  href="About Us.html">Contact US</a></li>
			<li><a href="new_home.html" >Logout</a></li>
			
		</ul>
	</div>
	
	</div>
		</div>
		
		</div>
		</div>
	
		
		<!-- Ending header navigation -->
		
		
		<div class="row">
		
		<div class="col-lg-6">
		
		<div id="container">
		<div id="main">
		<div class="bodycontent">
		
		<h3>About us:</h3>
	<p class="p1">Now a days there are so many ladies/girls who have some hobbies like Jewelry making, handmade personalized CARD MAKING, handicraft making, painting etc.
Some of the young ladies create Facebook pages or some other social media websites to showcase their talent and get orders from customers.
</p>
<p class="p1">
This website is created as a platform to register and showcase the creativity of all the talented ladies who are interested to earn money from their hobby by taking orders from the customers (public).
</p>


<h3>Advantage:</h3>

<ul type="disc">

<li>By enrolling in this website the designers get customers from different places and can earn money from this.</li>
<li>The designers will get more publicity and can develop their business based on the sale</li>
<li>They can also improve their ideas and trends in the market as they are getting a chance to communicate with the customers </li>
<li>Publicity will increase.</li>
<li>This site is also helpful for the Customers/public because it contains different categories of items and the details of the designers. So they can select an interested profile and place order easily.</li>
<li>Customers get a chance to communicate their ideas with the designers and can order customized items.</li>
</ul>


</div>
   </div>
   </div>
   </div>
	
		
		
		<div class="col-lg-6">
		
		<div id="container">
		<div id="main">
		<div class="bodycontent">
		
		<h3>welcome </h3>
	


<ul type="disc">

<li>By enrolling in this website the designers get customers from different places and can earn money from this.</li>
<li>The designers will get more publicity and can develop their business based on the sale</li>
<li>They can also improve their ideas and trends in the market as they are getting a chance to communicate with the customers </li>
<li>Publicity will increase.</li>
<li>This site is also helpful for the Customers/public because it contains different categories of items and the details of the designers. So they can select an interested profile and place order easily.</li>
<li>Customers get a chance to communicate their ideas with the designers and can order customized items.</li>
</ul>


</div>
   </div>
   </div>
   </div>
   	</div>
		<!-- strartig footer navigation -->
		<footer id="footer">
		
   <p class="navbar-text footcontent"  style="color:white; padding-left:40%;">Copyright &copy;Make your dreams come true!</p>
  

		</footer>
		   <!-- Ending footer navigation -->
		   
		   <?php
		 
$con=mysqli_connect("localhost","root","","dreamsdb")or die ("Couldn't connect");



$q2="Select * from tbl_basic_details";
$disp_result=mysqli_query($con,$q2);
while($row=mysqli_fetch_array($disp_result))
{

echo $row['firstname'];

}



?>
		   
		   
   </body>
   </html>
   
		