<?php
include("connection.php");

$name=$_POST['Name'];
$email=$_POST['mail'];
$phone=$_POST['phonem'];
$age=$_POST['Age'];
$address=$_POST['Address'];
$pass1=$_POST['password'];
$pass=md5($_POST['password']);

$cpass=($_POST['cpassword']);



$log="select * from login where Email='$email' and status='approved'";
$result = $conn->query($log);
if ($result->num_rows == 0) {


$sql = "INSERT INTO login (Email,Password,User_type,status)values('$email','$pass',1,'approved')";

if ($conn->query($sql) === TRUE) {
	$getd="SELECT Login_id from login where Email='$email' ";
	
	$res_logid=$conn->query($getd);
	$row=mysqli_fetch_array($res_logid);
	
	$lid=$row['Login_id'];
	$reg = "INSERT INTO  registration(Name,Age,Address,phone,Login_id)values('$name','$age','$address','$phone',$lid)";
	
} 
if ($conn->query($reg) ===TRUE) {
		
echo"<script>alert('success');window.location='new_login.php';</script>";
}
}
else
{
echo"<script>alert('Already Exist ');window.location='new_registration.php';</script>";
}

?>