3<?php
session_start();

include('connection.php');

 if (isset($_POST['update']))
  {


   $function=$_POST['function'];
  
   
   $id=$_POST['function_id'];
   echo "
<script>
     alert('$function_id');
</script>
";
  /*
   $q1 ="SELECT * FROM tbl_register WHERE email=$email1";
 
  $result=mysqli_query($conn,$q1);
   
   //$count=mysqli_num_rows($result);

   while($row=mysqli_fetch_array($result))
   {

   $email2=$row['email'];
}

//, grpname='$grpname' 


if ((strcmp($email,$email2)==0)) 
   {
     */


$sq = "UPDATE addfunction SET function='$function' where function_id='$id' ";
$upd=mysqli_query($conn,$sq);
 if($upd==TRUE)
 {
 echo "pooja Updated successfully";
    header('location:addfunction.php');
}
  
      else{
        echo "not updated";
      }


}
?>