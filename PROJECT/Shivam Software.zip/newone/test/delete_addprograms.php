<?php
$program_id=$_GET["program_id"];
//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
       //$db=new connection();

  
 $sql="update addprograms set status='disable' where program_id=$program_id ";
       $res2=$conn->query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Disable Successfully");
              window.location="addprograms.php";

              </script>
            <?php 
        }
?>