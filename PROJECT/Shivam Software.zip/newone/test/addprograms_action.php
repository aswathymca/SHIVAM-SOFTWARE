<?php
$program=$_POST["program"];


//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
      // $db=new connection();

   $sql11="select * from addprograms where program='$program'  and status='enable'";
       $res11=$conn->query($sql11); 
$n=mysqli_num_rows($res11);
if($n==0)
{
 $sql="insert into addprograms(program,status) values('$program','enable')";
       $res2=$conn->query($sql); 
      
          
            if($res2)
            {
              ?>
              <script type="">
                alert("program is added Successfully");
              window.location="addprograms.php";

              </script>
            <?php 
        }
}

else
{
  ?>
  <script type="">
                alert("program is Already Exist");
              window.location="addprograms.php";

              </script>
  <?php
}
?>




