<?php
$poojabooking_id=$_GET["poojabooking_id"];
//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
       //$db=new connection();"delete from addfunction where function_id=$function_id";

  
 $sql="update pooja_booking set  status='1' where poojabooking_id=$poojabooking_id ";
       $res2=$conn->query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert(" Approve Successfully");
              window.location="view_pooja_booking.php";

              </script>
            <?php 
        }
?>