try:
a=int(input("first no:");
b=int(input("second no:");
result=a/b;
print"result=",result
finally
print("executed always");
