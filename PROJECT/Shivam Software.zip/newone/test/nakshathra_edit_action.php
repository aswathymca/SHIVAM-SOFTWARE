3<?php
session_start();

include('connection.php');

 if (isset($_POST['update']))
  {


   $nakshathra=$_POST['nakshathra'];
  
   
   $id=$_POST['nakshathra_id'];
   echo "
<script>
     alert('$nakshathra_id');
</script>
";
  /*
   $q1 ="SELECT * FROM tbl_register WHERE email=$email1";
 
  $result=mysqli_query($conn,$q1);
   
   //$count=mysqli_num_rows($result);

   while($row=mysqli_fetch_array($result))
   {

   $email2=$row['email'];
}

//, grpname='$grpname' 


if ((strcmp($email,$email2)==0)) 
   {
     */


$sq = "UPDATE addnakshathra SET nakshathra='$nakshathra' where nakshathra_id='$id' ";
$upd=mysqli_query($conn,$sq);
 if($upd==TRUE)
 {
 echo "Nakshathra Updated successfully";
    header('location:addnakshathra.php');
}
  
      else{
        echo "not updated";
      }


}
?>