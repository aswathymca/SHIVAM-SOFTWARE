<?php   
session_start();
 include("connection.php");
$lid=$_SESSION['leader_id'];



$Name=$_POST['Name'];
$mail=$_POST['mail'];

$Address=$_POST['Address'];
$phonem=$_POST["phonem"];
$date=$_POST["date"];


	$qt="UPDATE leader SET Name='$Name',Address='$Address',phonem='$phonem',mail='$mail',date='$date' WHERE leader_id=$lid";
							
							//$updt=$conn->query($ql);		//

if ($conn->query($qt) === TRUE) {
		
		
		echo"<script>  alert('Updated successfully');
window.location='addleader.php';
		</script>";
		
}
else
	
	{	
						echo"<script>  alert('Not Updated');
						window.location='Edit_leader.php';
						
						</script>";
						
	}
							?>
							