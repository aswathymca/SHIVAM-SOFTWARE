<?php
$occassion=$_POST["occassion"];
$amount=$_POST["amount"];
//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
      // $db=new connection();

   $sql11="select * from addoccassion where occassion='$occassion' and amount=$amount and status='enable' ";
       $res11=$conn->query($sql11); 
$n=mysqli_num_rows($res11);
if($n==0)
{
 $sql="insert into addoccassion(occassion,amount,status) values('$occassion',$amount,'enable')";
       $res2=$conn->query($sql); 
      
          
            if($res2)
            {
              ?>
              <script type="">
                alert("occassion is added Successfully");
              window.location="addoccassion.php";

              </script>
            <?php 
        }
}

else
{
  ?>
  <script type="">
                alert("occassion is Already Exist");
              window.location="addoccassion.php";

              </script>
  <?php
}
?>




