<?php

//Include dboperation class file 
 include("connection.php");
$Name=$_POST["Name"];
$program=$_POST['program'];
$date=$_POST["date"];
$Address=$_POST['Address'];
$phonem=$_POST["phonem"];
$fname=$_POST["fname"];
$mname=$_POST["mname"];

 // code to create object of class dboperations
      // $db=new connection();

   //$sql11="select * from addchildren where Name='Anju' ";
//$res11=$conn->query($sql11); 
//$n=mysqli_num_rows($res11);

$check="SELECT * FROM `addchildren` WHERE Name='$Name' and Address='$Address' and fname='$fname' and mname='$mname'";
$c2=mysqli_query($conn,$check);
$n=mysqli_num_rows($c2);

if($n==0)
{
 $sql="INSERT INTO `addchildren` (`Name`, `date`, `Address`, `phonem`, `program_id`, `fname`, `mname`) VALUES ('$Name','$date','$Address','$phonem','$program','$fname','$mname')";
 $res2=mysqli_query($conn,$sql); 
 //"insert into addchildren(Name,Age,Address,phonem,program_id,fname,mname)values('$Name','$Age','$Address','$phonem','$program','$fname','$mname')";
       
            if($res2)
            {
				
              ?>
              <script type="">
                alert(" added Successfully");
              window.location="addchildren.php";

              </script>
            <?php 
        }
		

}
else
{
  ?>
 <script type="">
                alert(" Already Exist");
              window.location="addchildren.php";

              </script>
  <?php
		}
?>




