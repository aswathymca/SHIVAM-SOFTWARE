<?php   
session_start();
 include("connection.php");
$pid=$_SESSION['program_id'];

//$id=$_GET['addpooja_id'];

$program=$_POST['program'];

	$qt="UPDATE addprograms SET program='$program' WHERE program_id=$pid";
							
							//$updt=$conn->query($ql);

if ($conn->query($qt) === TRUE) {
		
		
		echo"<script>  alert('Updated successfully');
		window.location='addprograms.php';
		</script>";
		
}
else
	
	{	
						echo"<script>  alert('Not Updated');
						window.location='Edit_programs.php';
						
						</script>";
						
	}
							?>
							