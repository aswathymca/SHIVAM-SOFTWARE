<?php
session_start();
include("connection.php");

if(isset($_POST["submit"])){
	
	$pooja=$_POST['pooja'];
	$name=$_POST['name'];
	$Age=$_POST['Age'];
	
	$nakshathra=$_POST['Nakshathra'];
	$dbook=$_POST['Dbooking'];	
	$status='Unpaid';
	$login_id=$_SESSION['login_id'];
	$amount=$_POST["Amount"];
	$_SESSION["am"]=$amount;
	$datev="select * from pooja_booking where name='$name' and Age='$Age' and datebook='$dbook' and nakshathra_id=$nakshathra and addpooja_id=$pooja";
$result8=mysqli_query($conn,$datev);

if ($result8->num_rows == 0)
	{
	$sql1="select * from registration where Login_id=".$login_id;
	$res=mysqli_query($conn,$sql1);
	while($row=mysqli_fetch_array($res)){
		$reg_id=$row['Registration_id'];
		
	}
	
	$sql="insert into pooja_booking (name,Age,datebook,status,nakshathra_id,addpooja_id,registration_id) values('$name','$Age','$dbook','$status',$nakshathra,$pooja,$reg_id)";
	$q=mysqli_query($conn,$sql) or mysqli_error($conn);
	if ($q===true) {
		$sql6="select * from pooja_booking where name='$name' and Age='$Age' and datebook='$dbook' and status='$status' and nakshathra_id=$nakshathra and addpooja_id=$pooja and registration_id=$reg_id";
		$t=mysqli_query($conn,$sql6);
		$row=mysqli_fetch_array($t);
		$_SESSION['booking_id']=$row['poojabooking_id'];
		echo" <script>
		
		window.location.href='payment.php';</script>";
	} else {
		echo" <script>
			alert('failed!! please try again' +'$dbook'+'status='+'$status'+'pooja='+$pooja+'nakshathra='+$nakshathra+'login='+$login_id);
			window.location='poojabooking.php';</script>";
			
	}
}
else
{
echo"<script>alert('Already Booked');window.location.href='poojabooking.php';</script>";	
}
}
?>
