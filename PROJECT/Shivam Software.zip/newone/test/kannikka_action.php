<?php
session_start();
include("connection.php");

if(isset($_POST["submit"])){
	
$shivan=$_POST["shivan"];
$ganapathi=$_POST["ganapathi"];
$amma=$_POST["amma"];
$guru=$_POST["guru"];
$gulikan=$_POST["gulikan"];
$nagarajav=$_POST["nagarajav"];
$dhevi=$_POST["dhevi"];
$reshas=$_POST["reshas"];
$date=$_POST["date"];

?>
             
            <?php 
//Include dboperation class file 

 // code to create object of class dboperations
      // $db=new connection();

$sql11="select * from kannikka where date='$date'";
       $res11=$conn->query($sql11); 
$n=mysqli_num_rows($res11);
if($n==0)
{
 $sql="insert into kannikka(shivan,ganapathi,amma,guru,gulikan,nagarajav,dhevi,reshas,date) values('$shivan','$ganapathi','$amma','$guru','$gulikan','$nagarajav','$dhevi','$reshas','$date')";
       $res2=$conn->query($sql); 
      
          
            if($res2)
            {
              ?>
              <script type="">
                alert(" Added Successfully");
              window.location="kannikka.php";

              </script>
            <?php 
        }
}
else
{
  ?>
  <script type="">
                alert("Already added");
              window.location="kannikka.php";

              </script>
  <?php
}
}

?>




