<?php   
session_start();
 include("connection.php");
$pid=$_SESSION['addpooja_id'];

//$id=$_GET['addpooja_id'];

$poojaname=$_POST['pooja'];
$pamount=$_POST['amount'];
	$qt="UPDATE addpooja SET pooja='$poojaname', amount=$pamount WHERE addpooja_id=$pid";
							
							//$updt=$conn->query($ql);

if ($conn->query($qt) === TRUE) {
		
		
		echo"<script>  alert('Updated successfully');
		window.location='addpooja.php';
		</script>";
		
}
else
	
	{	
						echo"<script>  alert('Not Updated');
						window.location='Edit_addpooja.php';
						
						</script>";
						
	}
							?>
							