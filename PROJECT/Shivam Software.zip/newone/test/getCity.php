<?php
include("connection.php");
if (! empty($_POST["state_id"])) {
    
    $stateId = $_POST["state_id"];
$d="select amount from addpooja where addpooja_id='$stateId'";
$res=mysqli_query($conn,$d);  
$f=mysqli_fetch_array($res);
$price=$f['amount']; 
 $c=mysqli_num_rows($res);
if($c!=0)
{?>

<input type="text" value="10000"/>	
<?php
}
else
{
   ?>
<input type="text" value="<?php echo $price;?>"/>
<?php }
?>