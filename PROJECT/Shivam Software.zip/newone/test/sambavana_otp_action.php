	<?php
	session_start();
$sid=$_SESSION['sam_id'];
	include("connection.php");
$name=$_SESSION['name'];
$cardno=$_SESSION['cardno'];
$cvv=$_SESSION['cvv'];
$amount=$_SESSION['amount'];
$expiration=$_SESSION['expiration'];
if(isset($_POST["submitotp"])){
	$otp=$_POST['otpn'];
		$sql5="SELECT * from bank_info where cardno='1111111111111111' and cvv='222'";

//echo $current_balance;
$result2=mysqli_query($conn,$sql5);

$sql="SELECT * from bank_info where cardno='$cardno' and cvv='$cvv'and otp='$otp'";
//echo "$card_number";
//echo $old_balance;
$result=mysqli_query($conn,$sql);
$count=mysqli_num_rows($result);
if($count>0)
{

while($x1=mysqli_fetch_array($result2))
      {    
      $current_balance=$x1['balance'];
      //echo $current_balance;
      }
		$otp=$_POST["otpn"];
		$skl=mysqli_query($conn,"select * from bank_info where cardno='$cardno'");
		$skl2=mysqli_fetch_array($skl);
		$old_balance=$skl2['balance'];

			if($old_balance<$amount)
			{
			echo "<script>alert('insufficent ammount in account'); </script>";

			}
			else
			{
			$new_balance=$old_balance-$amount;
			$admin_balance=$current_balance+$amount;
			$count=0;
			$sql3="UPDATE bank_info SET balance='$new_balance'  WHERE cardno='2323232323232323' ";
			$result22=mysqli_query($conn,$sql3);





			$sql36="UPDATE bank_info SET balance='$admin_balance' WHERE cardno='1111111111111111'";
			$result21=mysqli_query($conn,$sql36);

			$sql2="INSERT INTO bank_account(name,cardno,cvv,expiration,amount)values('$name','$cardno','$cvv','$expiration','$amount')";
			$k=mysqli_query($conn,$sql2);

						if($k)
						{
							$book="UPDATE `sambavana` SET `status` = 'Paid' WHERE `sambavana`.`sambavana_id` = $sid;";
							$booking=mysqli_query($conn,$book);
							$otp1="UPDATE `bank_info` SET `otp`='0' WHERE cardno='2323232323232323'";
							$booking=mysqli_query($conn,$otp1);
						 echo "<script>alert('payment success'); window.location= 'sambavana.php';;
						</script>";
							//header('location:poojabooking.php');
						}
						else
						{
						echo "<script>alert('payment failed');</script>";
						}
			}
}
else{
echo "<script>alert('incorrect otp');window.location='sambavana_bank_action.php'</script>";	
}
		
		
	}
	

		



?>