<?php
$category=$_POST["category"];

//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
      // $db=new connection();

   $sql11="select * from category1 where category='$category'";
       $res11=$conn->query($sql11); 
$n=mysqli_num_rows($res11);
if($n==0)
{
 $sql="insert into category1(category) values('$category')";
       $res2=$conn->query($sql); 
      
          
            if($res2)
            {
              ?>
              <script type="">
                alert("Category is added Successfully");
              window.location="category.php";

              </script>
            <?php 
        }
}

else
{
  ?>
  <script type="">
                alert("Category is Already Exist");
              window.location="category.php";

              </script>
  <?php
}
?>




