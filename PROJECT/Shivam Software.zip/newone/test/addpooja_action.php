<?php
$pooja=$_POST["pooja"];
$amount=$_POST["amount"];

//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
      // $db=new connection();

   $sql11="select * from addpooja where pooja='$pooja' and amount='$amount' and status='enable'";
       $res11=$conn->query($sql11); 
$n=mysqli_num_rows($res11);
if($n==0)
{
 $sql="insert into addpooja(pooja,amount,status) values('$pooja','$amount','enable')";
       $res2=$conn->query($sql); 
      
          
            if($res2)
            {
              ?>
              <script type="">
                alert("pooja is added Successfully");
              window.location="addpooja.php";

              </script>
            <?php 
        }
}

else
{
  ?>
  <script type="">
                alert("pooja is Already Exist");
              window.location="addpooja.php";

              </script>
  <?php
}
?>




