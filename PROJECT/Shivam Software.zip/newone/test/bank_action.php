<?php
session_start();
$book_id=$_SESSION['booking_id'];
include("connection.php");
if(isset($_POST['submit']))
{
$name=$_POST['name'];
$_SESSION['name']=$name;
$cardno=$_POST['cardno'];
$_SESSION['cardno']=$cardno;
$cvv=$_POST['cvv'];
$_SESSION['cvv']=$cvv;
$expiration=$_POST['expiration'];
$_SESSION['expiration']=$expiration;
$amount=(int)$_POST['amount'];
$_SESSION['amount']=$amount;
$sql="SELECT * from bank_info where cardno='$cardno' and cvv='$cvv'";
//echo "$card_number";
//echo $old_balance;
$result=mysqli_query($conn,$sql);
$sql5="SELECT * from bank_info where cardno='1111111111111111' and cvv='222'";
//echo $current_balance;
$result2=mysqli_query($conn,$sql5);
while($x1=mysqli_fetch_array($result2))
      {    
      $current_balance=$x1['balance'];
      //echo $current_balance;
      }
while($x=mysqli_fetch_array($result))
      {    
      $old_balance=(int)$x['balance'];
      //echo $old_balance;
      }
$r=mysqli_num_rows($result);
if($r>0)
{
	$to = "aswathypushpan1998@gmail.com";
            $subject = "Your OTP is";
            $chars="0123456789";
            $password = substr(str_shuffle($chars),0,6);
              $message = "YOUR OTP " . $password;
            $headers = "From: sreelekshmip@mca.ajce.in";        
            if(mail($to, $subject, $message, $headers)){
                     $sql4="UPDATE bank_info SET otp='$password'  WHERE cardno='$cardno' ";
			$result22=mysqli_query($conn,$sql4);
			}

	?>
	
	
	

<?php 
}
else
{
echo "<script>alert('incorrect card details');window.location= 'payment.php'</script>";	
}
}





?>
<html>
<head>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >

<link rel="stylesheet" href="styles.css" >

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
	body {
  padding-top: 40px;
  padding-bottom: 40px;
  background-color: #eee;
}

.form-signin {
  max-width: 330px;
  padding: 15px;
  margin: 0 auto;
}
.form-signin .form-signin-heading,
.form-signin .checkbox {
  margin-bottom: 10px;
}
.form-signin .checkbox {
  font-weight: normal;
}
.form-signin .form-control {
  position: relative;
  height: auto;
  -webkit-box-sizing: border-box;
     -moz-box-sizing: border-box;
          box-sizing: border-box;
  padding: 10px;
  font-size: 16px;
}
.form-signin .form-control:focus {
  z-index: 2;
}
.form-signin input[type="email"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
	</style>
    
	</head>
    <form class="form-signin" action="otp_action.php"  method="POST">
    <br>
    <br>
    <br>
   <br>
    <br>
    <br>
    <br>
	<center><h2>Enter OTP</h2></center>
	<br>
		<center><h3>Check your mail for otp</h3></center>
    <div class="input-group">
	

    <span class="input-group-addon" id="basic-addon1">OTP</span>
    <input type="text" name="otpn" id="otpn" class="form-control" autocomplete="off" required>
    </div>
        <br>
    <input class="btn btn-lg btn-primary btn-block" type="submit" name="submitotp" id="submitotp" value="OK">
    
    </form>
</html>
<?php
	if(!isset($_SESSION["login_id"]))
{
	header("location:../index.php");
	exit;
}
	?>

 