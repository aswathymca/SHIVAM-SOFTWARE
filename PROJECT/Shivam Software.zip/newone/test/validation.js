function validate_brand()
{
var brand=document.getElementById("brand").value;
                            
          if(brand=="" ||  !isNaN(brand) ){
             alert("Please Enter Valid Brand");
               document.f1.brand.focus();
                                return false;
 } 	
}
function validate_category()
{
var category=document.getElementById("category").value;
                            
          if(category=="" ||  !isNaN(category) ){
             alert("Please Enter Valid category");
               document.f1.category.focus();
                                return false;
 } 	
}
