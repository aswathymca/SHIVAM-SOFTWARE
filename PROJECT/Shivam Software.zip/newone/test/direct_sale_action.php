<?php
include_once("../dbconnection.php");
$db=new dbconnection();
$cost=$_POST['cost'];
$product=$_POST['product'];
$quantity=$_POST['quantity'];
$customer_name=$_POST['customer_name'];

$totprice=$_POST['totprice'];

$phone=$_POST['phone'];
$state=$_POST['state'];
$district=$_POST['district'];
$city=$_POST['city'];


//date_default_timezone_set('Asia/Kolkata');
//$sale_date=date('d-m-y H:i');

 $sql="insert into tbl_sale(product_id,quantity,totalprice,customer_name,place_id,phone_no)values('$product','$quantity','$totprice','$customer_name','$city','$phone')";
$res=$db->execute_query($sql);

if($res)
{
	header("location:direct_sale.php");                                     
}      
?>