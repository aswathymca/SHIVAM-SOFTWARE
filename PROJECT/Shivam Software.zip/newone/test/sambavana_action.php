<?php
session_start();
include("connection.php");

if(isset($_POST["submit"])){
	
	
	$date=$_POST['date'];
	$amount=$_POST["Amount"];
	$_SESSION["am"]=$amount;
	
	$function=$_POST['function'];
	$status='Unpaid';
	$login_id=$_SESSION['login_id'];
	$sql1="select * from registration where Login_id=".$login_id;
	$res=mysqli_query($conn,$sql1);
	while($row=mysqli_fetch_array($res)){
		$reg_id=$row['Registration_id'];
	}
	$sql="insert into sambavana(date,Login_id,Registration_id,function_id,status) values('$date',$login_id,$reg_id,$function,'$status')";
	$q=mysqli_query($conn,$sql) or mysqli_error($conn);
	if ($q===true) {
		$sql6="select * from sambavana where date='$date' and Login_id=$login_id and registration_id=$reg_id and function_id=$function and status='$status'";
		$t=mysqli_query($conn,$sql6)or die(mysqli_error($conn));
		$rowc=mysqli_num_rows($t);
		while($row=mysqli_fetch_array($t)){
			
		$_SESSION['sam_id']=$row['sambavana_id'];
		echo" <script>window.location.href='spayment.php';</script>";
		}
	}
	else{
		echo"<script>alert('Failed')</script>";
	}	
}
?>