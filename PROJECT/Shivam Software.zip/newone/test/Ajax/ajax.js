$(document).ready(function() {
 $('#brand').on('keyup', function() {
    var alpha=/^[a-zA-Z]+$/;
    var brand = $('#brand').val();
if(!brand.match(alpha))
{
 $("#error_brand").show();
 $('#error_brand').html("Only Alphabets"); 
}
else
{
  $("#error_brand").hide();   
}

 });
    $('#brand_save').on('click', function() {
        
        var brand = $('#brand').val();
    
        if(brand!="" &&  isNaN(brand)){
            $.ajax({
                url: "brand_action.php",
                type: "POST",
                data: {
                    brand: brand
                },
                cache: false,
                success: function(dataResult){
                    var dataResult = JSON.parse(dataResult);
                    if(dataResult.statusCode==200){
                        $('#brand').val('');
                        $("#success").show();
                        $("#error").hide();
                        $('#success').html(dataResult.message); 
                        $('#result').html(dataResult.result);   
                                            

                    }
                    else if(dataResult.statusCode==201){
                        $("#success").hide();
                        $("#error").show();
                        $('#error').html('Error occured !'); 
                     
                    }
                    
                }
            });
        }
        else{
            $("#success").hide();
            $("#error").show();
                        $('#error').html('Please Enter Valid  the field !'); 
        
        }
    });
});

function display_cost()
{
        var xmlhttp;
      
        var product=document.getElementById('pooja').value;
        var url="display_cost.php?val="+product;
        if (window.XMLHttpRequest)
        {
            xmlhttp=new XMLHttpRequest();
        }
        else
        {
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function()
        {
            
            if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
                document.getElementById("Amount").value=xmlhttp.responseText;
            }
        }

        xmlhttp.open("GET", url, true);
        xmlhttp.send();
}
function display_amount()
{
        var xmlhttp;
      
        var product=document.getElementById('occassion').value;
        var url="display_amount.php?val="+product;
        if (window.XMLHttpRequest)
        {
            xmlhttp=new XMLHttpRequest();
        }
        else
        {
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function()
        {
            
            if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
                document.getElementById("Amount").value=xmlhttp.responseText;
            }
        }

        xmlhttp.open("GET", url, true);
        xmlhttp.send();
}
function display_function()
{
        var xmlhttp;
      
        var product=document.getElementById('function').value;
        var url="display_function.php?val="+product;
        if (window.XMLHttpRequest)
        {
            xmlhttp=new XMLHttpRequest();
        }
        else
        {
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function()
        {
            
            if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
                document.getElementById("Amount").value=xmlhttp.responseText;
            }
        }

        xmlhttp.open("GET", url, true);
        xmlhttp.send();
}
function display_total()
{

        var quantity=document.getElementById('quantity').value;
        var cost=document.getElementById('cost').value;
        if(quantity=="" || cost=="")
        {

         document.getElementById("totprice").value=0;
        }
        else
        {
          var tot=parseInt(quantity)*parseInt(cost);
         document.getElementById("totprice").value=tot;  
        }
        
       
}
function display_state()
{
  var country=document.getElementById("country").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('state').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_state.php?country="+country,true);
  xmlhttp.send();

}
function display_district()
{
  var state=document.getElementById("state").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('district').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_district.php?state="+state,true);
  xmlhttp.send();

}
function display_place()
{
 var district=document.getElementById("district").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('city').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_place.php?district="+district,true);
  xmlhttp.send();
 
}
