<?php session_start() ?>
<!DOCTYPE HTML>
<html>
<head>
<title>Online Hardware Shop</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<script src="js/simpleCart.min.js"> </script>
<script src="js/amcharts.js"></script>	
<script src="js/serial.js"></script>	
<script src="js/light.js"></script>	
<!-- //lined-icons -->
<script src="js/jquery-1.10.2.min.js"></script>
   <!--pie-chart--->
<script src="js/pie-chart.js" type="text/javascript"></script>
<script type="text/javascript" src="../js/ajax.js">

	

</script>
<script type="text/javascript" src="Ajax/ajax.js"></script>
 <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#3bb2d0',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#fbb03b',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ed6498',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

           
        });

    </script>
    <script src="validation.js" type="text/javascript"></script>
    <script type="text/javascript" src="../js/ajax.js"></script>
</head> 
<body>
	<?php
	if(isset($_SESSION["slogid"]))
	{
	?>
   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<div class="header-section">
			<!-- top_bg -->
						<div class="top_bg">
							
								<div class="header_top">
									<div class="top_right">
										
									</div>
									<div class="top_left">
										<h2><span></span> Call us : 032 2352 782</h2>
									</div>
										<div class="clearfix"> </div>
								</div>
							
						</div>
					<div class="clearfix"></div>
				<!-- /top_bg -->
				</div>
				<div class="header_bg">
						
							<div class="header">
								<div class="head-t con">
									<h1>Online Hardware Shop</h1>
								
								<div class="clearfix"> </div>
							</div>
						</div>
					
				</div>
					<!-- //header-ends -->
				
				<!--content-->
			<div class="content">
<div class="women_main">
	<!-- start content -->
	<div class="contact" style="min-height: 300px;">
	
				

<h2>Direct Sale</h2>	
		
				<div class="row">
						<form action="direct_sale_action.php" method="post" name="f1" id="direct_sale">	
					
					<div class="col-md-5">

						<div>
						    	<span><label>Product</label></span>
						    	<span><?php
						    include_once("../dbconnection.php");
						    $db=new dbconnection();
						    $res=$db->execute_query("select * from tbl_product");
						    ?>
						    <select name="product" class="form-control" id="product" onchange="display_cost()"><
						    		<option value="0">--Select--</option>				   
						    <?php
						    while($row=mysqli_fetch_array($res))
						    {
						    	$cost=$row['cost'];
						    	?>
						    	
						    	<option value="<?php echo $row['product_id']?>"><?php echo $row['product_name']?></option> <?php }?>
						    </select></span>
						    </div>
 <div>
						    	<span><label>Price 	<span><input type="text" id="cost"  class="form-control"  name="cost"></span>
						    </div>
						    	<div>

						    	<span><label>Quantity</label></span>
						   <input name="quantity" type="text" class="form-control" id="quantity" autocomplete="off" onkeyup="display_total()" ></span>
						    </div>
						   
						    <div>
						    	
						    	<span>Total Price</label></span>
						    	<span><input type="text"  class="form-control"  id="totprice" name="totprice"></span>
						    </div>
						     <div>
						    	<span><label>Customer Name</label></span>
						    	<span><input type="text"  class="form-control"  id="customer_name" name="customer_name"></span>
						    </div>

					</div>
					<div class="col-md-5">
						
						    

						    <div>
						    	<span><label>State</label></span>
						    	
                           <?php 

                           	$re=$db->execute_query("select * from tbl_state");
						    ?>
						    <span><select name="state" id="state" class="form-control" onchange="display_district()">
                            <option value="0">--Select--</option>				   
						    <?php
						    while($row=mysqli_fetch_array($re))
						    {
						    	?>
						   	<option value="<?php echo $row['state_id']?>"> 	
						    <?php echo $row['state_name']?></option> <?php

						    }
                           ?>
                            </select></span>
						    </div>

						    <div>
						    	<span><label>District</label></span>
						    	<span><select name="district" id="district" class="form-control" onchange="display_place()">
                            <option value="0">--Select--</option>
                            </select></span>
						    </div>
						    
						    <div>
						    	<span><label>Place</label></span>
						    	<span><select name="city" id="city" class="form-control">
                            <option value="0">--Select--</option>
                            </select></span>
						    </div>
						    <div>
						    	<span><label>Phone Number</label></span>
						    	<span><input type="text"  class="form-control"  id="phone" name="phone"></span>
						    </div>


						    <div>&nbsp;&nbsp;&nbsp;&nbsp;
						<span><label></label></span>
						<span>
					<input type="submit" value="Submit" class="btn btn-danger" onClick="return validate_direct_sale()">
					</span>
				</div>

					</div>
					

					<div class="clearfix">
					</div>
					
				
					</form>


<!--Validation-->
<style type="text/css">
    #direct_sale label.error {
    color: #FB3A3A;
    display: inline-block;
    margin: 0px 0 0px 0px;
    padding: 0;
    text-align: left;
    }
</style>
            

    <!-- jQuery Form Validation library -->
    <script src="../jquery/jquery.js"></script>
<script src="../jquery/jquery-ui.js"></script>
    <script src="../js/jquery_validate.js"></script>
             
  <script type="text/javascript">
  (function ($, W, D)
  {
  var JQUERY4U = {};
  JQUERY4U.UTIL =
      {
          setupFormValidation: function ()
          {
            $.validator.addMethod(
    "regex",
    function(value, element, regexp) {
        var check = false;
        return this.optional(element) || regexp.test(value);
    },
    "Not a valid Input."
);
   
          //form validation rules
          $("#direct_sale").validate({
              rules: {
             
                   product: {
                      required: true,
                  },
                 
                  quantity:
                  {
                  	required: true,
                     regex : /^[0-9]+$/,
                  },
                 
 customer_name: {
                      required: true,
                     regex : /^[A-Za-z ]+$/,
                       
                     
                  },
                  state: {
                      required: true,
                  },
                  district: {
                      required: true,
                  },
                  city: {
                      required: true,
                  },
                 phone: {
                      required: true,
                       minlength: 10,
                       maxlength: 10,
                        regex : /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/
                     
                  },
            
                  
              },
              messages: {
              
                product: "Please choose product",
                quantity:"Please enter quantity",
                customer_name:"Please enter valid Customer Name",
                 state: "Please choose state",
                  district: "Please choose district",
                   city: "Please choose place",
                phone:"Please enter valid phone number",
                
                
                    
                     
              },
              submitHandler: function (form) {
              form.submit();
              }
          });
        }
      }
  //when the dom has loaded setup form validation rules
  $(D).ready(function ($) {
      JQUERY4U.UTIL.setupFormValidation();
  });
  })(jQuery, window, document);
</script>





				</div>
			
		</div>
				

















						   <div>

						   		
								
						  </div>
						
				    </label>
				</span>
			</div>
<div>
	&nbsp;
	&nbsp;
</div>
				    <div class="row" >
					
					<table class="table table-striped">
	
	
	<thead>
							<tr><th>No.</th><th>Product</th><th>Quantity</th><th>Total Price</th><th>Customer Name</th><th>Phone Number</th><th>Place</th><th>Sale Date</th></tr></thead><tbody>
							<?php
							 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();
$count=1;


 $sql="select * from tbl_sale inner join tbl_product on tbl_sale.product_id=tbl_product.product_id inner join tbl_place on tbl_place.place_id=tbl_sale.place_id ";
       $res2=$db->execute_query($sql); 
       while ($row=mysqli_fetch_array($res2)) {

       	?>
       	<tr ><td><?php echo $count; ?></td>
       		<td><?php echo $row["product_name"] ?></td>
       		<td><?php echo $row["quantity"] ?></td>
       		<td><?php echo $row["totalprice"] ?></td>
       			<td><?php echo $row["customer_name"] ?></td>
       		<td><?php echo $row["phone_no"] ?></td>
       		<td><?php echo $row["place_name"] ?></td>
       		<td><?php echo $row["sale_date"] ?></td>
       		</tr>
       	<?php
       	$count++;
       }
							?></tbody>
						</table>
				</div>

				
  				
	<!-- end content -->
	<div class="foot-top">
	
		
		<div class="col-md-6 s-c">
			
		</div>
			<div class="clearfix"> </div>
	
</div>
<div class="footer">
					
					<div class="clearfix"> </div>
						<p>All Rights Reserved | Design by <a href="#">Online Harware Shop</a></p>
			</div>
</div>

</div>
			<!--content-->
		</div>
</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<div class="sidebar-menu">
					<header class="logo1">
						<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
					</header>
						<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
									<ul id="menu" >
										<li><a href="index.php"><i class="fa fa-tachometer"></i> <span>Home</span></a></li>
										<li ><a href="category.php"><i class="fa fa-list-alt"></i> <span>Category</span></a></li>
										<li><a href="brand.php"><i class="fa fa-bold"></i> <span>Brand</span></a></li>
										<li><a href="product.php"><i class="fa fa-list-alt"></i> <span>Product</span></a></li>
										<li class="active"><a href="direct_sale.php"><i class="fa fa-gift"></i> <span>Direct Sale</span></a></li>
										<li><a href="order_list.php"><i class="fa fa-shopping-cart"></i> <span>Order List</span></a></li>
										<li><a href="delivered_list.php"><i class="fa fa-shopping-cart"></i> <span>Delivered List</span></a></li>
										<li><a href="feedback.php"><i class="fa fa-comments"></i> <span>Feedback</span></a></li>
										<li ><a href="view_user.php"><i class="fa fa-group"></i> <span>User's List</span></a></li>
										<li><a href="report.php"><i class="fa fa-file"></i> <span>Report</span></a></li>
										<li><a href="change_password.php"><i class="fa fa-key"></i> <span>Change Password</span></a></li>
										<li><a href="../logout.php"><i class="fa fa-sign-out"></i> <span>Logout</span></a></li>
										  
								  </ul>
								</div>
							  </div>
							  <div class="clearfix"></div>		
							</div>
							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});
							</script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->
<script language="javascript" type="text/javascript" src="js/jquery.flot.js"></script>
	<script type="text/javascript">

	$(function() {

		// We use an inline data source in the example, usually data would
		// be fetched from a server

		var data = [],
			totalPoints = 300;

		function getRandomData() {

			if (data.length > 0)
				data = data.slice(1);

			// Do a random walk

			while (data.length < totalPoints) {

				var prev = data.length > 0 ? data[data.length - 1] : 50,
					y = prev + Math.random() * 10 - 5;

				if (y < 0) {
					y = 0;
				} else if (y > 100) {
					y = 100;
				}

				data.push(y);
			}

			// Zip the generated y values with the x values

			var res = [];
			for (var i = 0; i < data.length; ++i) {
				res.push([i, data[i]])
			}

			return res;
		}

		// Set up the control widget

		var updateInterval = 30;
		$("#updateInterval").val(updateInterval).change(function () {
			var v = $(this).val();
			if (v && !isNaN(+v)) {
				updateInterval = +v;
				if (updateInterval < 1) {
					updateInterval = 1;
				} else if (updateInterval > 2000) {
					updateInterval = 2000;
				}
				$(this).val("" + updateInterval);
			}
		});

		var plot = $.plot("#placeholder", [ getRandomData() ], {
			series: {
				shadowSize: 0	// Drawing is faster without shadows
			},
			yaxis: {
				min: 0,
				max: 100
			},
			xaxis: {
				show: false
			}
		});

		function update() {

			plot.setData([getRandomData()]);

			// Since the axes don't change, we don't need to call plot.setupGrid()

			plot.draw();
			setTimeout(update, updateInterval);
		}

		update();

		// Add the Flot version string to the footer

		$("#footer").prepend("Flot " + $.plot.version + " &ndash; ");
	});

	</script>
<!-- /real-time -->
<script src="js/jquery.fn.gantt.js"></script>
    <script>

		$(function() {

			"use strict";

			$(".gantt").gantt({
				source: [{
					name: "Sprint 0",
					desc: "Analysis",
					values: [{
						from: "/Date(1320192000000)/",
						to: "/Date(1322401600000)/",
						label: "Requirement Gathering", 
						customClass: "ganttRed"
					}]
				},{
					name: " ",
					desc: "Scoping",
					values: [{
						from: "/Date(1322611200000)/",
						to: "/Date(1323302400000)/",
						label: "Scoping", 
						customClass: "ganttRed"
					}]
				},{
					name: "Sprint 1",
					desc: "Development",
					values: [{
						from: "/Date(1323802400000)/",
						to: "/Date(1325685200000)/",
						label: "Development", 
						customClass: "ganttGreen"
					}]
				},{
					name: " ",
					desc: "Showcasing",
					values: [{
						from: "/Date(1325685200000)/",
						to: "/Date(1325695200000)/",
						label: "Showcasing", 
						customClass: "ganttBlue"
					}]
				},{
					name: "Sprint 2",
					desc: "Development",
					values: [{
						from: "/Date(1326785200000)/",
						to: "/Date(1325785200000)/",
						label: "Development", 
						customClass: "ganttGreen"
					}]
				},{
					name: " ",
					desc: "Showcasing",
					values: [{
						from: "/Date(1328785200000)/",
						to: "/Date(1328905200000)/",
						label: "Showcasing", 
						customClass: "ganttBlue"
					}]
				},{
					name: "Release Stage",
					desc: "Training",
					values: [{
						from: "/Date(1330011200000)/",
						to: "/Date(1336611200000)/",
						label: "Training", 
						customClass: "ganttOrange"
					}]
				},{
					name: " ",
					desc: "Deployment",
					values: [{
						from: "/Date(1336611200000)/",
						to: "/Date(1338711200000)/",
						label: "Deployment", 
						customClass: "ganttOrange"
					}]
				},{
					name: " ",
					desc: "Warranty Period",
					values: [{
						from: "/Date(1336611200000)/",
						to: "/Date(1349711200000)/",
						label: "Warranty Period", 
						customClass: "ganttOrange"
					}]
				}],
				navigate: "scroll",
				scale: "weeks",
				maxScale: "months",
				minScale: "days",
				itemsPerPage: 10,
				onItemClick: function(data) {
					alert("Item clicked - show some details");
				},
				onAddClick: function(dt, rowId) {
					alert("Empty space clicked - add an item!");
				},
				onRender: function() {
					if (window.console && typeof console.log === "function") {
						console.log("chart rendered");
					}
				}
			});

			$(".gantt").popover({
				selector: ".bar",
				title: "I'm a popover",
				content: "And I'm the content of said popover.",
				trigger: "hover"
			});

			prettyPrint();

		});

    </script>
		   <script src="js/menu_jquery.js"></script>
		  <?php 
}
else
{
	header("location:../index.php");
}
		  ?>
</body>
</html>