<?php
session_start();
include("connection.php");

if(isset($_POST["submit"])){
	
	$occassion=$_POST['occassion'];
	$fdate=$_POST['fdate'];

	
	$amount=$_POST["Amount"];
	$_SESSION["am"]=$amount;
	
	$status='Unpaid';
	$login_id=$_SESSION['login_id'];
	$datev="select * from hallbooking where fdate='$fdate'";
$result5 = $conn->query($datev);
if ($result5->num_rows == 0) {
	$sql1="select * from registration where Login_id=".$login_id;
	$res=mysqli_query($conn,$sql1);
	while($row=mysqli_fetch_array($res)){
		$reg_id=$row['Registration_id'];
	}
	$sql="INSERT INTO `hallbooking` (`hallbooking_id`, `fdate`, `Login_id`, `occassion_id`, `Registration_id`, `status`) VALUES (NULL, '$fdate','$login_id', '$occassion', '$reg_id', '$status');";
	$q=mysqli_query($conn,$sql) or mysqli_error($conn);
	if ($q===true) {
		$sql6="select * from hallbooking where fdate='$fdate'  and Login_id=$login_id and occassion_id=$occassion and registration_id=$reg_id and status='$status'";
		$t=mysqli_query($conn,$sql6)or die(mysqli_error($conn));
		$rowc=mysqli_num_rows($t);
		while($row=mysqli_fetch_array($t)){
			
		$_SESSION['hbooking_id']=$row['hallbooking_id'];
		echo" <script>window.location.href='hpayment.php';</script>";
		}
		//
	}
	else{
		echo"<script>alert('Failed')</script>";
	}	
}
else
{
	echo"<script>alert('Already Booked in the date');window.location.href='hallbooking.php';</script>";
}
}
?>