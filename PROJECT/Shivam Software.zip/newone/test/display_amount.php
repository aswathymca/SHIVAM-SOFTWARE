<?php
$occassion=$_GET["val"];
//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
     //  $db=new dbconnection();

  
 //$sql="select * from addpooja where addpooja_id=$pooja";
       $sql2="select * from addoccassion where occassion_id='$occassion' ";
			$res3=$conn->query($sql2);
			
			while ($rowLogin=mysqli_fetch_array($res3)) 
                {
                   $amount=$rowLogin['amount'];
				   echo $amount;
                }

              ?>
            