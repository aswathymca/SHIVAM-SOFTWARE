<?php
include_once("../dbconnection.php");
$db=new dbconnection();
$category=$_POST['category'];
$brand=$_POST['brand'];
$pname=$_POST['pname'];
//$name=$_FILES["file"]["name"];

$short_desc=$_POST['Short_desc'];
$quantity=$_POST['quantity'];
$model=$_POST['model'];
$cost=$_POST['cost'];


 $ext = explode('.', basename($_FILES['file']['name']));//explode file name from dot(.) 
        $file_extension = end($ext); //store extensions in the variable

              $h = 0;
                $dir = 'product_image/';
    if ($handle = opendir($dir)) {
        while (($file = readdir($handle)) !== false){
            if (!in_array($file, array('.', '..')) && !is_dir($dir.$file)) 
                 $h++;
        }
    }

    $n1=$h+1;
        $fname=$n1.".".$file_extension;
      move_uploaded_file($_FILES["file"]["tmp_name"], "product_image/".$fname);
$res=$db->execute_query("insert into tbl_product(product_name,model,description,cost,category_id,quantity,photo,brand_id)values('$pname','$model','$short_desc','$cost','$category','$quantity','$fname','$brand')");


//move_uploaded_file($_FILES["file"]["tmp_name"],"imagestemp/".$_FILES["file"]["name"]);
//echo "Product inserted successfully";
if($res)
{
	header("location:product.php?flag=0");                                     
}    
?>