<?php
include("connection.php");
if(isset($_POST['leader'])){
	
	$name=$_POST['Name'];
	
	$address=$_POST['Address'];
	$phone=$_POST['phonem'];
	$email=$_POST['mail'];
	$date=$_POST['date'];
	$filename2 = $_FILES["photo"]["name"];
move_uploaded_file($_FILES["photo"]["tmp_name"], "images/" . $filename2); 
	$pass=MD5($date);
	$to = "$email";
        $from="admin";
		$subject = "Your Password";
		$message = "Please use this password to login " . $date;
		$headers = "From:".$from;        
		if(mail($to, $subject, $message, $headers)){
			echo "<script>";
			echo "alert(' Password has been sent to leader email id')";
			echo"</script>"; 
		

		}else{
			echo "<script>";
			echo "alert('Failed to Recover your password, try again')";
			echo "</script>";
	
		}
	$sql1 = "INSERT INTO login (Email,Password,User_type,status)values('$email','$pass',2,'approved')";
	$res1=mysqli_query($conn,$sql1)or die(mysqli_error($conn));
	if($res1){
		$sql2 = "INSERT INTO leader (Name,Address,phonem,mail,date,photo)values('$name','$address','$phone','$email','$date','$filename2')";
		$res2=mysqli_query($conn,$sql2)or die(mysqli_error($conn));
		if($res2){
			?>
              <script type="">
                alert(" Success");
              window.location.href="addleader.php";

              </script>
            <?php 
	}
	}
}

?>