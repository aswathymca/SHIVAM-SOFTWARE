<?php
$nakshathra_id=$_GET["nakshathra_id"];
//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
       //$db=new connection();

  
 $sql="update addnakshathra set status='disable' where nakshathra_id=$nakshathra_id ";
       $res2=$conn->query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Disable Successfully");
              window.location="addnakshathra.php";

              </script>
            <?php 
        }
?>