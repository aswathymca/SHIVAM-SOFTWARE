<?php
$leader_id=$_GET["leader_id"];
//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
       //$db=new connection();

  
 $sql="update leader set status='1' where leader_id=$leader_id ";
       $res2=$conn->query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Disable Successfully");
              window.location="addleader.php";

              </script>
            <?php 
        }
?>