<?php   
session_start();
 include("connection.php");
$pid=$_SESSION['shanthi_id'];

//$id=$_GET['addpooja_id'];

$shanthi=$_POST['shanthi'];
$type=$_POST['type'];
$Age=$_POST["Age"];
$Address=$_POST['Address'];
$phonem=$_POST["phonem"];

$filename2 = $_FILES["photo"]["name"];
move_uploaded_file($_FILES["photo"]["tmp_name"], "images/" . $filename2); 
	$qt="UPDATE addshanthi SET shanthi='$shanthi',type='$type',Age='$Age',Address='$Address',phonem='$phonem',photo='$filename2' WHERE shanthi_id=$pid";
							
							//$updt=$conn->query($ql); 

if ($conn->query($qt) === TRUE) {
		
		
		echo"<script>  alert('Updated successfully');window.location='addshanthi.php';
		
		</script>";
		
}
else
	
	{	
						echo"<script>  alert('Not Updated');
						window.location='Edit_addshanthi.php';
						
						</script>";
						
	}
							?>
							