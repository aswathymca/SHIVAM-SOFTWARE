<?php
session_start();

include('connection.php');

 if (isset($_POST['update']))
  {


   $pooja=$_POST['pooja'];
   $amount=$_POST['amount'];
   
   $id=$_POST['addpooja_id'];
   echo "
<script>
     alert('$addpooja_id');
</script>
";
  /*
   $q1 ="SELECT * FROM tbl_register WHERE email=$email1";
 
  $result=mysqli_query($conn,$q1);
   
   //$count=mysqli_num_rows($result);

   while($row=mysqli_fetch_array($result))
   {

   $email2=$row['email'];
}

//, grpname='$grpname' 


if ((strcmp($email,$email2)==0)) 
   {
     */


$sq = "UPDATE addpooja SET pooja='$pooja', amount='$amount'  where addpooja_id='$id' ";
$upd=mysqli_query($conn,$sq);
 if($upd==TRUE)
 {
 echo "pooja Updated successfully";
    header('location:addpooja.php');
}
  
      else{
        echo "not updated";
      }


}
?>