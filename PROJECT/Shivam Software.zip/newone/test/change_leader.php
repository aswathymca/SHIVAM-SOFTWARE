<?php   
session_start();
 include("connection.php");
$pid=$_SESSION['leader_id'];

//$id=$_GET['addpooja_id'];


$filename2 = $_FILES["photo"]["name"];
move_uploaded_file($_FILES["photo"]["tmp_name"], "images/" . $filename2); 
	$qt="UPDATE leader SET photo='$filename2' WHERE leader_id=$pid";
							
							//$updt=$conn->query($ql);  

if ($conn->query($qt) === TRUE) {
		
		
		echo"<script>  alert('Updated successfully');
window.location='addleader.php';
		</script>";
		
}
else
	
	{	
						echo"<script>  alert('Not Updated');
						window.location='change_leader.php';
						
						</script>";
						
	}
							?>
							