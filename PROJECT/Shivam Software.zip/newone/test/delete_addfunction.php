<?php
$function_id=$_GET["function_id"];
//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
       //$db=new connection();"delete from addfunction where function_id=$function_id";

  
 $sql="update addfunction set status='disable' where function_id=$function_id ";
       $res2=$conn->query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert(" Disable Successfully");
              window.location="addfunction.php";

              </script>
            <?php 
        }
?>