<?php
session_start();
include("connection.php");

if(isset($_POST["submit"])){
	
	
	$date=$_POST['date'];
	$section=$_POST['section'];
	
	
	$status=0;
	$login_id=$_SESSION['login_id'];
	$datev="select * from ramayanam where date='$date' and section='$section'";
$result5 = $conn->query($datev);
if ($result5->num_rows == 0) {
	$sql1="select * from registration where Login_id=".$login_id;
	$res=mysqli_query($conn,$sql1);
	while($row=mysqli_fetch_array($res)){
		$reg_id=$row['Registration_id'];
	}
	$sql="insert into ramayanam(section,date,Login_id,Registration_id,status) values('$section','$date',$login_id,$reg_id,$status)";
	$q=mysqli_query($conn,$sql) or mysqli_error($conn);
	if($q){
		echo"<script>alert('Booking successfull');window.location.href='ramayanam.php';</script>";
	} else{
		echo"<script>alert('Failed')</script>";
	}
}
else
{
	echo"<script>alert('Already Booked in the same date');window.location.href='ramayanam.php';</script>";
}	
}
?>