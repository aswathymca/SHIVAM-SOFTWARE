<?php   
session_start();
 include("connection.php");
$pid=$_SESSION['login_id'];

//$id=$_GET['addpooja_id'];

$Name=$_POST['Name'];
$Age=$_POST['Age'];

$Address=$_POST['Address'];
$Phone=$_POST["Phone"];



	$qt="UPDATE registration SET Name='$Name',Age='$Age',Address='$Address',Phone='$Phone' WHERE Login_id=$pid";
							
							//$updt=$conn->query($ql);

if ($conn->query($qt) === TRUE) {
		
		
		echo"<script>  alert('Updated successfully');
		window.location='profile_edit.php';
		</script>";
		
}
else
	
	{	
						echo"<script>  alert('Not Updated');
						window.location='profile_edit.php';
						
						</script>";
						
	}
							?>
							