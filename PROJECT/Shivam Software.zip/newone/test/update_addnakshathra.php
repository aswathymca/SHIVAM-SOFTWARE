<?php   
session_start();
 include("connection.php");
$pid=$_SESSION['nakshathra_id'];

//$id=$_GET['addpooja_id'];

$nakshathra=$_POST['nakshathra'];

	$qt="UPDATE addnakshathra SET nakshathra='$nakshathra'  WHERE nakshathra_id=$pid";
							
							//$updt=$conn->query($ql);

if ($conn->query($qt) === TRUE) {
		
		
		echo"<script>  alert('Updated successfully');
		window.location='addnakshathra.php';
		</script>";
		
}
else
	
	{	
						echo"<script>  alert('Not Updated');
						window.location='Edit_addnakshathra.php';
						
						</script>";
						
	}
							?>
							