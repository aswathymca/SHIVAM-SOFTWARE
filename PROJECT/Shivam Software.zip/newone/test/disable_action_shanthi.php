<?php
$shanthi_id=$_GET["shanthi_id"];
//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
       //$db=new connection();

  
 $sql="update addshanthi set status='enable' where shanthi_id=$shanthi_id ";
       $res2=$conn->query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Enable Successfully");
              window.location="addshanthi.php";

              </script>
            <?php 
        }
?>