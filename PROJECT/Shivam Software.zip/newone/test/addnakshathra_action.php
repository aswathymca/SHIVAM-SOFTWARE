<?php
$nakshathra=$_POST["nakshathra"];


//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
      // $db=new connection();

   $sql11="select * from addnakshathra where nakshathra='$nakshathra' and status='enable' ";
       $res11=$conn->query($sql11); 
$n=mysqli_num_rows($res11);
if($n==0)
{
 $sql="insert into addnakshathra(nakshathra,status) values('$nakshathra','enable')";
       $res2=$conn->query($sql); 
      
          
            if($res2)
            {
              ?>
              <script type="">
                alert("Nakshathara is added Successfully");
              window.location="addnakshathra.php";

              </script>
            <?php 
        }
}

else
{
  ?>
  <script type="">
                alert("Nakshathara is Already Exist");
              window.location="addnakshathra.php";

              </script>
  <?php
}
?>




