<?php
$function=$_POST["function"];

$amount=$_POST["amount"];
//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
      // $db=new connection();

   $sql11="select * from addfunction where function='$function' and amount=$amount and status='enable' ";
       $res11=$conn->query($sql11); 
$n=mysqli_num_rows($res11);
if($n==0)
{
 $sql="insert into addfunction(function,amount,status) values('$function',$amount,'enable')";
       $res2=$conn->query($sql); 
      
          
            if($res2)
            {
              ?>
              <script type="">
                alert("function is added Successfully");
              window.location="addfunction.php";

              </script>
            <?php 
        }
}

else
{
  ?>
  <script type="">
                alert("Function is Already Exist");
              window.location="addfunction.php";

              </script>
  <?php
}
?>




