<?php session_start() ?>
<!DOCTYPE HTML>
<html>
<head>
<title>SHIVAM</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<script src="js/simpleCart.min.js"> </script>
<script src="js/amcharts.js"></script>	
<script src="js/serial.js"></script>	
<script src="js/light.js"></script>	
<!-- //lined-icons -->
<script src="js/jquery-1.10.2.min.js"></script>
   <!--pie-chart--->
<script src="js/pie-chart.js" type="text/javascript"></script>
 <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#3bb2d0',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#fbb03b',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ed6498',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

           
        });

    </script>
</head> 
<body>
	<?php
	include("connection.php"); 
	if(!isset($_SESSION["login_id"]))
{
	header("location:../index.php");
	exit;
}
$id=$_SESSION["login_id"];
	$sql1="SELECT  *  FROM `registration` WHERE `login_id`='$id'";
$res=mysqli_query($conn,$sql1);
	while($row=mysqli_fetch_array($res)){
		$Name=$row['Name'];
	}
	?>
   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<div class="header-section">
			<!-- top_bg -->
						<div class="top_bg">
							
								<div class="header_top">
									<div class="top_right">
										
									</div>
									<div class="top_left">
										<h2><?php echo($Name) ?></h2>
									</div>
										<div class="clearfix"> </div>
								</div>
							
						</div>
					<div class="clearfix"></div>
				<!-- /top_bg -->
				</div>
				<div class="header_bg">
						
							<div class="header">
								<div class="head-t con">
									<h1>SHIVAM SOFTWARE</h1>
								
								<div class="clearfix"> </div>
							</div>
						</div>
					
				</div>
					<!-- //header-ends -->
				
				<!--content-->
			<div class="content">
<div class="women_main">
	<!-- start content -->
	<div class="contact" style="min-height: 300px;">				
					
				  
  				<div class="clearfix"><img src="temple1.jpg" style="width:1040px; height:500px;"><table class="table">
	
	
	
							
							
							
							
							<tr><th style="font-size: 40px; font-weight: bold; color:red; "><h4><i>Sreemahadheva Temple, also know as Pakkanathappan Temple is one of the major temples in kerala,located in the heart of Punchavayal. The temple, dedicated to Load Shiva. The temple is
							now under the administration of Devasam Bord. the temple in its current form was built in 1940.
                            As part of increasing local participation in temple management,
                              Mahadheva Temple consisting leading Hindu members of Punchavayal.
							  The activities of the temple did good to the overall development of the temple.</h4></th></tr>
							<tr><th style="font-size: 40px; font-weight: bold; color:red; "><h4><i>The temple is built in typical Kerala temple architecture. The temple has two gates, the western Gopuram and eastern Gopuram. Recently a new marriage hall constructed at the northern side. </h4></th></tr>
  
  
       	</tbody>
						</table>
						<div class="footer">
					<marquee>			<div class="clearfix" class="foot-top" class="alert alert-success" style="font-size: 40px; font-weight: bold; color:orange; "><i></div>	<div class="clearfix" class="foot-top" class="alert alert-success" style="font-size: 20px; color:red; "><i>ഓം നമഃശിവായ മന്ത്രത്തിന്റെ മഹിമ വർണനാതീതമാണ്.  നിത്യേന  ജപിക്കുന്നവർക്ക് ഏത് ആപത്ഘട്ടത്തെയും തരണം ചെയ്യാനുള്ള ആത്മബലം ലഭിക്കും. പഞ്ചാക്ഷരീമന്ത്രത്തിൽ പ്രപഞ്ചശക്തികൾ ഒളിഞ്ഞിരിക്കുന്നു. ഓം എന്നാൽ നശിക്കാത്തതെന്നാണ്. ‘ന’ ഭൂമിയെയും ‘മ’ ജലത്തെയും ‘ശി’ അഗ്നിയെയും ‘വാ’ വായുവിനെയും ‘യ’ ആകാശത്തെയും സൂചിപ്പിക്കുന്നു. ചുരുക്കിപ്പറഞ്ഞാൽ പഞ്ചഭൂതങ്ങളെയും ഈ മന്ത്രം പ്രതിനിധീകരിക്കുന്നു.ഈ മന്ത്രം തുടർച്ചയായി ചൊല്ലുമ്പോൾ നാം നമ്മെത്തന്നെ ഭഗവാനിൽ സമർപ്പിക്കുന്നു. നമ്മുടെ അഹംഭാവത്തെ ഇല്ലാതാക്കി മനസ്സിലെ മാലിന്യങ്ങൾ നീക്കാനുള്ള ശക്തി ഈ മന്ത്രത്തിനുണ്ട്. ഓം നമഃശിവായ മന്ത്രം ജപിക്കാം എന്ന പ്രത്യേകതയുണ്ട്. കൂടാതെ നിത്യവും പഞ്ചാക്ഷരീ മന്ത്രം ജപിക്കുന്നവർക്കു ഗ്രഹദോഷങ്ങൾ ബാധിക്കുകയില്ല.


</div>	</marquee>	
					<div class="clearfix"> </div>
						<p>All Rights Reserved | Design by <a href="#">Shivam</a></p>
			</div></div>		
			  </div>
							<?php
							 include("connection.php");
 // code to create object of class dboperations
    //   $db=new connection();
$count=1;


 $sql="select * from addshanthi";
       $res2=$conn->query($sql);
       while ($row=mysqli_fetch_array($res2)) {

       	?>
  
       	<?php
       	$count++;
       }
							?></tbody>
						</table></div>		
			  </div>

	<!-- end content -->
	
			<!--content-->
		</div>
</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<div class="sidebar-menu">
					<header class="logo1">
						<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
					</header>
						<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
									<ul id="menu" >
									<li><a href="userindex.php"></i> <span>HOME</span></a></li>
										<li ><a href="poojabooking.php"></i> <span> POOJA BOOKING</span> </a></li>
										 <li ><a href="hallbooking.php"></i> <span> HALL BOOKING</span> </a></li>
										 <li ><a href="sambavana.php"></i> <span> SAMBAVANA</span> </a></li>
										 <li ><a href="ramayanam.php"></i> <span> PARAYANAM BOOKING</span> </a></li>
										 <li ><a href="userchangepass.php"></i> <span> CHANGE PASSWORD</span> </a></li>
										 <li ><a href="viewshanthi.php"></i> <span> VIEW SHANTHI</span> </a></li>
										  <li ><a href="viewpayments.php"></i> <span> VIEW PAYMENTS</span> </a></li>
										  <li ><a href="userprofile_edit.php"></i> <span> PROFILE EDIT</span> </a></li>
										 <li ><a href="userabout.php"></i> <span> ABOUT US</span> </a></li>
										 <li ><a href="usercontact.php"></i> <span> CONTACT US</span> </a></li>
										  <li ><a href="logout.php"></i> <span> LOG OUT</span> </a></li>
										  
								  </ul>
								</div>
							  </div>
							  <div class="clearfix"></div>		
							</div>
							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});
							</script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->
<script language="javascript" type="text/javascript" src="js/jquery.flot.js"></script>
	<script type="text/javascript">

	$(function() {

		// We use an inline data source in the example, usually data would
		// be fetched from a server

		var data = [],
			totalPoints = 300;

		function getRandomData() {

			if (data.length > 0)
				data = data.slice(1);

			// Do a random walk

			while (data.length < totalPoints) {

				var prev = data.length > 0 ? data[data.length - 1] : 50,
					y = prev + Math.random() * 10 - 5;

				if (y < 0) {
					y = 0;
				} else if (y > 100) {
					y = 100;
				}

				data.push(y);
			}

			// Zip the generated y values with the x values

			var res = [];
			for (var i = 0; i < data.length; ++i) {
				res.push([i, data[i]])
			}

			return res;
		}

		// Set up the control widget

		var updateInterval = 30;
		$("#updateInterval").val(updateInterval).change(function () {
			var v = $(this).val();
			if (v && !isNaN(+v)) {
				updateInterval = +v;
				if (updateInterval < 1) {
					updateInterval = 1;
				} else if (updateInterval > 2000) {
					updateInterval = 2000;
				}
				$(this).val("" + updateInterval);
			}
		});

		var plot = $.plot("#placeholder", [ getRandomData() ], {
			series: {
				shadowSize: 0	// Drawing is faster without shadows
			},
			yaxis: {
				min: 0,
				max: 100
			},
			xaxis: {
				show: false
			}
		});

		function update() {

			plot.setData([getRandomData()]);

			// Since the axes don't change, we don't need to call plot.setupGrid()

			plot.draw();
			setTimeout(update, updateInterval);
		}

		update();

		// Add the Flot version string to the footer

		$("#footer").prepend("Flot " + $.plot.version + " &ndash; ");
	});

	</script>
<!-- /real-time -->
<script src="js/jquery.fn.gantt.js"></script>
    <script>

		$(function() {

			"use strict";

			$(".gantt").gantt({
				source: [{
					name: "Sprint 0",
					desc: "Analysis",
					values: [{
						from: "/Date(1320192000000)/",
						to: "/Date(1322401600000)/",
						label: "Requirement Gathering", 
						customClass: "ganttRed"
					}]
				},{
					name: " ",
					desc: "Scoping",
					values: [{
						from: "/Date(1322611200000)/",
						to: "/Date(1323302400000)/",
						label: "Scoping", 
						customClass: "ganttRed"
					}]
				},{
					name: "Sprint 1",
					desc: "Development",
					values: [{
						from: "/Date(1323802400000)/",
						to: "/Date(1325685200000)/",
						label: "Development", 
						customClass: "ganttGreen"
					}]
				},{
					name: " ",
					desc: "Showcasing",
					values: [{
						from: "/Date(1325685200000)/",
						to: "/Date(1325695200000)/",
						label: "Showcasing", 
						customClass: "ganttBlue"
					}]
				},{
					name: "Sprint 2",
					desc: "Development",
					values: [{
						from: "/Date(1326785200000)/",
						to: "/Date(1325785200000)/",
						label: "Development", 
						customClass: "ganttGreen"
					}]
				},{
					name: " ",
					desc: "Showcasing",
					values: [{
						from: "/Date(1328785200000)/",
						to: "/Date(1328905200000)/",
						label: "Showcasing", 
						customClass: "ganttBlue"
					}]
				},{
					name: "Release Stage",
					desc: "Training",
					values: [{
						from: "/Date(1330011200000)/",
						to: "/Date(1336611200000)/",
						label: "Training", 
						customClass: "ganttOrange"
					}]
				},{
					name: " ",
					desc: "Deployment",
					values: [{
						from: "/Date(1336611200000)/",
						to: "/Date(1338711200000)/",
						label: "Deployment", 
						customClass: "ganttOrange"
					}]
				},{
					name: " ",
					desc: "Warranty Period",
					values: [{
						from: "/Date(1336611200000)/",
						to: "/Date(1349711200000)/",
						label: "Warranty Period", 
						customClass: "ganttOrange"
					}]
				}],
				navigate: "scroll",
				scale: "weeks",
				maxScale: "months",
				minScale: "days",
				itemsPerPage: 10,
				onItemClick: function(data) {
					alert("Item clicked - show some details");
				},
				onAddClick: function(dt, rowId) {
					alert("Empty space clicked - add an item!");
				},
				onRender: function() {
					if (window.console && typeof console.log === "function") {
						console.log("chart rendered");
					}
				}
			});

			$(".gantt").popover({
				selector: ".bar",
				title: "I'm a popover",
				content: "And I'm the content of said popover.",
				trigger: "hover"
			});

			prettyPrint();

		});

    </script>
		   <script src="js/menu_jquery.js"></script>
		    <?php 
//}
//else
//{
	//header("location:../index.php");
//}
		  ?>
</body>
</html>