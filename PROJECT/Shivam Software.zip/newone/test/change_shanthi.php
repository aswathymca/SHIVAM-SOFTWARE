<?php   
session_start();
include("connection.php");
$pid=$_SESSION['shanthi_id'];
$filename2 = $_FILES["photo"]["name"];
    move_uploaded_file($_FILES["photo"]["tmp_name"], "images/" . $filename2); 
	$qt="UPDATE addshanthi SET photo='$filename2' WHERE shanthi_id=$pid";
	if ($conn->query($qt) === TRUE)
		{
		echo"<script>  alert('Updated successfully');
		window.location='addshanthi.php';
		</script>";
		}
		
	else
	    {	
		echo"<script>  alert('Not Updated');
	    window.location='change_shanthi.php';
		</script>";
		}
?>
							