<?php   
session_start();
 include("connection.php");
$pid=$_SESSION['function_id'];
$amount=$_POST['amount'];
//$id=$_GET['addpooja_id'];

$function=$_POST['function'];

	$qt="UPDATE addfunction SET function='$function',amount='$amount'  WHERE function_id=$pid";
							
							//$updt=$conn->query($ql);

if ($conn->query($qt) === TRUE) {
		
		
		echo"<script>  alert('Updated successfully');
		window.location='addfunction.php';
		</script>";
		
}
else
	
	{	
						echo"<script>  alert('Not Updated');
						window.location='Edit_addfunction.php';
						
						</script>";
						
	}
							?>
							