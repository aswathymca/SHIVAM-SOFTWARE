<?php   
session_start();
 include("connection.php");
$pid=$_SESSION['occassion_id'];

//$id=$_GET['addpooja_id'];

$occassion=$_POST['occassion'];
$amount=$_POST['amount'];

	$qt="UPDATE addoccassion SET occassion='$occassion', amount='$amount'  WHERE occassion_id=$pid";
							
							//$updt=$conn->query($ql);

if ($conn->query($qt) === TRUE) {
		
		
		echo"<script>  alert('Updated successfully');
		window.location='addoccassion.php';
		</script>";
		
}
else
	
	{	
						echo"<script>  alert('Not Updated');
						window.location='Edit_addoccassion.php';
						
						</script>";
						
	}
							?>
							