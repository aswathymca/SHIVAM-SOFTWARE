<?php

$shanthi=$_POST["shanthi"];
$type=$_POST['type'];
$Age=$_POST["Age"];
$Address=$_POST['Address'];
$phonem=$_POST["phonem"];

//Include dboperation$filename = $_FILES["photo"]["name"];
$filename2 = $_FILES["photo"]["name"];
move_uploaded_file($_FILES["photo"]["tmp_name"], "images/" . $filename2); 
 
 // code to create object of class dboperations
      // $db=new connection();
include("connection.php");
   $sql11="select * from addshanthi where shanthi='$shanthi' and type='$type' and Age='$Age' and Address='$Address' and phonem='$phonem' and status='enable' ";
       $res11=$conn->query($sql11); 
$n=mysqli_num_rows($res11);
if($n==0)
{
 $sql="insert into addshanthi(shanthi,type,Age,Address,phonem,photo,status) values('$shanthi','$type','$Age','$Address','$phonem','$filename2','enable')";
       $res2=$conn->query($sql); 
      
          
            if($res2)
            {
              ?>
              <script type="">
                alert("shanthi is added Successfully");
              window.location="addshanthi.php";

              </script>
            <?php 
        }
}

else
{
  ?>
  <script type="">
                alert("Shanthi is Already Exist");
              window.location="addshanthi.php";

              </script>
  <?php
}
?>




