<?php
$category_id=$_GET["category_id"];
//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
       //$db=new connection();

  
 $sql="delete from category1 where category_id=$category_id";
       $res2=$conn->query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Category is deleted Successfully");
              window.location="category.php";

              </script>
            <?php 
        }
?>