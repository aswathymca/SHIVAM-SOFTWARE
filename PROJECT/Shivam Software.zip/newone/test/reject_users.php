<?php
$Login_id=$_GET["Login_id"];
//Include dboperation class file 
 include("connection.php");
 // code to create object of class dboperations
       //$db=new connection();"delete from addfunction where function_id=$function_id";

  
 $sql="update login set status='rejected' where Login_id=$Login_id ";
       $res2=$conn->query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert(" Rejected Successfully");
              window.location="registereduser.php";

              </script>
            <?php 
        }
?>