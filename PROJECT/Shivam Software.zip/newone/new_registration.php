<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- Bootsrap, CSS file -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" href="styles.css">
 <link rel="stylesheet" href="login1.css">
 
  <!-- Javascript and jQuery files -->
  
  
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="Home/js/jquery-1.10.2.js" type="text/javascript"></script>
      <script src="Home/js/bootstrap.js" type="text/javascript"></script>
      <script src="Home/js/login-register.js" type="text/javascript"></script>
      <script src="Home/js/jquery.min.js" type="text/javascript"></script>
      <script src="Home/js/jquery-ui.js" type="text/javascript"></script>

<script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script> 
  <script type="text/javascript" src="http://dev.jquery.com/view/trunk/plugins/validate/jquery.validate.js"></script> 
  <script type="text/javascript"> 
  </script>

  
   <!-- page title -->
   <title>Shivam</title>
    <!-- Internal css -->
	<style>
	
	.bg
	{
	background-color:lightgrey;
	background-repeat: no-repeat;
   background-size: cover;
    background-image:url("banner.jpg");
   	
	}
	
	 .logo
	{
   
	float:left;
    width: 16%;
    height:8%;
	
	}
	
	
	.slider_image_holder{
    width: 100%;
    height: 30%;
	margin-top:1%;
	margin-bottom:10%;
	border:2px solid black;
	
    }
	.contents
	{
	width: 100%;
    height: 100%;
	
	
	border:2px solid black;
	}
	.foot
	{
	
	margin-bottom:0%;
	}
	</style>
	
	
	<!-- internal javascrpt code -->
   <script>
   
   $('.message a').click(function(){
   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
});
   
		function loginValid(mail,passwrd)

		{
                    	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
			var passw=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
			
		   if(mail.value.match(mailformat))
			{
				
				//document.login.email.focus();
				if(passwrd.value.match(passw)) 
					{ 
			
					//window.location="succ_login.php";
					//window.location="succes_login.php";
					
					return true;
	
					}
					else
					{ 
				
					alert('Please enter a valid password...! Your password should be 8 to 20 characters which contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character');
					
					window.location="new_login.php";
					
					}
			}
		  else
			{
			alert("Please enter a valid Email-id and password !");
			document.login.email.focus();
			
			}


		}
	</script>
	<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
   <link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
   <script src="js/3dslider.js"></script>
   </head>
   
   <body class="bg">
   
   <!-- starting header navigation -->
   <div class="row">
   <div class="col-lg-12">
	<div class="navbar navbar-inverse navbar-fixed-top">
	
	<div class="container">
	
	
	<button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse" >
	<span class="icon-bar"></span">
	<span class="icon-bar"></span">
	<span class="icon-bar"></span">
	
	</button>
			
	<div class="collapse navbar-collapse navHeaderCollapse">
	
		<ul class="nav navbar-nav navbar-right">
			<li><h4><a href="index.php">Home</a></h4>
			</li>
			
			
			
			
			
			<li ><h4><a href="new_login.php" >&nbsp;&nbsp;Login</a></h4></li>
			<li class="active"><h4><a href="new_registration.php">&nbsp;&nbsp;Registration</a></h4></li>
				
			
		</ul>
	</div>
	
	</div>
		</div>
		<!-- Ending header navigation -->
		
		</div>
		</div>
	
		<center>
<div class="row">
<div >

 <form   action="registeraction.php" class="container1" name="Login" id="Login" method="POST">

    <h2>Registration</h2>
	<label for="date" class="control-label"></label>
<input type="text" class="input input1 form-control" autocomplete="off" id="Name" name="Name" placeholder="Enter Name"  onchange="Validatename()"; required>

			            <label class="errortext" style="display:nne; color:red" id="name_l"></label>
                                           <script>
                                        function Validatename()
                                            {
                                                  var val = document.getElementById('Name').value;
                                                  if (!val.match(/^[A-Za-z][A-Za-z" "]{2,}$/))
                                                  {
                                                      $("#name_l").html('Only Alphabets Allowed..!').fadeIn().delay(4000).fadeOut();
                                                      document.getElementById('Name').value = "";
                                                      return false;
                                                  }
                                                  return true;
                                              }
                                              </script>
      
    Date of birth  (dd/mm/yyyy) <input  type="date"  id="Age" class="input input1 form-control" autocomplete="off" name="Age"  style="width:340px"; oninput="this.className = ''"  onblur="return checkDOB()" required>
      <p id="p4"></p>
         <script type="text/javascript">
            function checkDOB() {
            var dateString = document.getElementById('Age').value;
            var myDate = new Date(dateString);
            var today = new Date();
            if ((today.getFullYear() - myDate.getFullYear() > 10) && (today.getFullYear() - myDate.getFullYear() < 90)) {
            $('#p4').hide();
            }
            else{
            $('#p4').show();
            $('#p4').text("* Eligibility between 10 years and 90 years ONLY. *");
            $("#Age").focus();
            }
            }
       </script>
	   <br>
	<textarea class="input input1 form-control" id="Address" name="Address" placeholder="Enter Address"   onchange="Validateaddress()"; required></textarea>

			            <label class="errortext" style="display:nne; color:red" id="address1"></label>
						
								
						<br>
                                          <input type="text" class="input input1 form-control" id="phonem"  placeholder="Enter Phone Number"  autocomplete="off" name="phonem"  onchange="Validatephone()"; required>
			             <label class="errortext" style="display:none; color:red" id="phone1"></label>
                                              <script>
                                              function Validatephone()
                                              {
                                                  var val = document.getElementById('phonem').value;
                                                  if (!val.match(/^[7-9][0-9]{9,9}$/))
                                                  {
                                                  $("#phone1").html('Must. 10 and Only Numbers Allowed..!').fadeIn().delay(4000).fadeOut();
                                                  document.getElementById('phonem').value = "";
                                                      return false;
                                                  }
                                                  return true;
                                              }
                                              </script>
<br>
			    <input type="text" class="input input1 form-control" id="mail" autocomplete="off"  name="mail" placeholder="Enter Mail Id"   onchange="Validateemail3()"; required>	
			            <label class="errortext" style="display:nne; color:red" id="email_1"></label>
                                              	            		            		     
			                            <script>
                                              function Validateemail3()
                                              {
                                                   var email = document.getElementById('mail');
                                                     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                                                     if (!filter.test(email.value)) {
                                                      email.value="";
                                                      $("#email_1").html('Please provide a valid email').fadeIn().delay(4000).fadeOut();
                                                      return false;
                                                      }
                                                  return false;
                                              }
                                              </script>     
	
			            <input type="password" class="input input1 form-control" id="password" name="password"  placeholder="Enter Password"  onchange="Validatepass()"; required>

<label class="errortext" style="display:nne; color:red" id="psw_2"></label>
                                               <script>
                                              function Validatepass()
                                              {
                                                   var password = document.getElementById('password');
                                                     var filter = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/;
                                                     if (!filter.test(password.value)) {
                                                      password.value="";
                                                      $("#psw_2").html('Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters ').fadeIn().delay(4000).fadeOut();
                                                      return false;
                                                      }
                                                  return false;
                                              }

                                              </script>
	
			            <input type="password" class="input input1 form-control" id="cpassword"  name="cpassword" placeholder="Enter confirm Password"  onchange="Validatecpassword()"; required>
			            <label class="errortext" style="display:nne; color:red" id="password_1"></label>
						<span  id="errorCpswrd" name="errorCpswrd" style="display:nne; color:red" id="password_1"></span>
<script>
                                      function Validatecpassword()
                                      {

						var passw=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
						var passwrd=document.getElementById("password").value;
						var cpasswrd=document.getElementById("cpassword").value;

								
						if(document.getElementById("cpassword").value==null ||Login.cpassword.value.length==0)
							{
							document.getElementById("errorCpswrd").innerHTML="Mandatory Field!";

							}

						else if(document.getElementById("cpassword").value.match(passw))
							{
							document.getElementById("errorCpswrd").innerHTML=" ";
							
									if(passwrd==cpasswrd)
												{ 	document.getElementById("errorCpswrd").innerHTML=" ";
												
													}
												else{
												document.getElementById("errorCpswrd").innerHTML="Password and confirm password did not match!";

												}
							}

							else
							{
							document.getElementById('errorCpswrd').innerHTML="Password and confirm password should be valid and  same";
							 document.getElementById("cpassword").value="";
							 
							 }


																  
										  
										  
										  
										  
										  
										  
                                         /* var pas = document.getElementById('password').value;
                                          var cpas = document.getElementById('cpassword').value;
										  
										  if(cpas==null || Login.cpassword.value.length==0)
										  {
											  
										  }
										  
                                          if (pas!=cpas)
                                          {
                                          $("#password_1").html('Password Miss Match..!').fadeIn().delay(4000).fadeOut();
                                             
											document.getElementById('cpassword').focus();
											  return false;
                                          }
                                          if (pas==cpas)
                                          {
                                          $("#password_1").html('Password  Match..!').fadeOut();
                                              return true;
                                          }
                                        //  return true;
										
										
										*/
                                      }
                                      </script>

    <input type="submit" name="submit" value="submit"  class="buttonlogin login-hover-color"/>
	



  </form>
</div>
</div>
</center>
		
   <!-- Ending body content-->
  
  

		
		
   </body>
   </html>
   
	