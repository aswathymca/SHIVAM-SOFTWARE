<?php session_start(); 
$_SESSION=array();
session_destroy();
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>SHIVAM</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href="bootstrap\css\bootstrap.min.css" rel="stylesheet">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="bootstrap\js\bootstrap.min.js"></script>
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="login.css"/>
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<link rel="stylesheet" href="indexfooter.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
		<link rel="stylesheet" href="css/3dslider.css" />
   <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
   <link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
   <script src="js/3dslider.js"></script>
   </head>
		

	<?php
		require 'menu.php';
	?>

		<!-- Banner -->
			<section id="banner" class="wrapper">
				<div class="container">
				<marquee><h2></h2></marquee>
				<p >ഓം നമഃ ശിവായ</p>
				<br><br>
				



			</section>

		<!-- One -->
			<section id="one" class="wrapper style1 align-center">
				<div class="container">
					<header>
						<h2>SHIVAM</h2>
						<p>Sreemahadheva Temple, also know as Pakkanathappan Temple is one of the major temples in kerala,located in the heart of Punchavayal. The temple, dedicated to Load Shiva. The temple is
							now under the administration of Devasam Bord. the temple in its current form was built in 1940.
                            As part of increasing local participation in temple management,
                              Mahadheva Temple consisting leading Hindu members of Punchavayal.</p>
					</header>
					
				</div>
			</section>


		<!-- Footer -->
		<footer class="footer-distributed" style="background-color:black" id="aboutUs">
		
		

		<div class="footer-center">
			<div>
				<i class="fa fa-map-marker"></i>
				<p style="font-size:20px">Shiva shekthram<span>Pakkanam</span></p>
			</div>
			<div>
				<i class="fa fa-phone"></i>
				<p style="font-size:20px">9946201621</p>
			</div>
			<div>
				<i class="fa fa-envelope"></i>
				<p style="font-size:20px"><a href="mailto:agroculture@gmail.com" style="color:white">shivashekthrapakkanum@gmail.com</a></p>
			</div>
		</div>

		<div class="footer-right">
						
		</div>

	</footer>


			<div id="id01" class="modal">

  <form class="modal-content animate" action="slogaction.php" method='POST'>
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
    </div>

    <div class="container">
    <h3>Login</h3>
							<form method="post" action="slogaction.php">
								<div class="row uniform 50%">
									<div class="7u$">
										<input type="email" style="width:85%"  placeholder="Email Id" name="mail" id="mail" required>
									</div>
									<div class="7u$">
										<input type="password" style="width:85%" placeholder="Password" name="password" id="password" required>
									</div>
								</div>
									
									<center>
									<div class="row uniform">
										<div class="7u 12u$(small)">
											<input type="submit" value="Login" />
										</div>
									</div>
									</center>
								</div>
							</form>
						</section>
</div>
    </div>
    </div>
  </form>
</div>


<div id="id02" class="modal">

  <form class="modal-content animate" action="registeraction.php" method='POST'>
    <div class="imgcontainer">
      <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
    </div>

    <div class="container">

<section>
							<h3>SignUp</h3>
							<form method="post" action="registeraction.php">
								<center>
								<div class="row uniform">
									<div class="7u$">
										<input type="text"  name="Name" id="Name" style="width:85%"	placeholder="Name"   required>
										 <p id="p1"></p>
                 <script>
                 $("#Name").on("blur", function() {
    if ( $(this).val().match('^[a-zA-Z]{3,16}$') ) {
       $('#p1').hide();
    } else {
         $('#p1').show();
       $('#p1').text("* please enter a valid name *");
        $("#Name").focus();
        
    }
});
    </script>     
									</div>
      
									<div class="7u$">
										<input type="text"  name="Age" id="Age" style="width:85%"	placeholder="Age"   required>
									</div>
								    <div class="7u$">
										<input type="text"  name="Address" id="Address" style="width:85%"	placeholder="Address"   required>
										<p id="p11"></p>
                 <script>
                 $("#Address").on("blur", function() {
    if ( $(this).val().length==0 ) {
      $('#p11').show();
       $('#p11').text("* required field *");
        $("#Address").focus();
    } else {
          $('#p11').hide();
        
        
    }
});
    </script>             
									</div>
									
								<div class="7u$">
										<input type="text"  name="phonem" id="phonem" style="width:85%"	placeholder="Phone Number"   required>
										<p id="p9"></p>
                 <script>
                 $("#phonem").on("blur", function() {
    if ( $(this).val().match('^[6-9][0-9]{9,9}$') ) {
       $('#p9').hide();
    } else {
         $('#p9').show();
       $('#p9').text("* please enter a valid mobile number *");
        $("#mob").focus();
        
    }
});
    </script>  

									</div>
									
									
									<div class="7u$">
										<input type="email" style="width:85%"  placeholder="Email Id" name="mail" id="mail" required>
									</div>
									<div class="7u$">
										<input type="password" style="width:85%" placeholder="Password" name="password" id="password" required>
									</div>
									<div class="7u$">
										<input type="password" style="width:85%" placeholder="Confirm Password" name="cpassword" id="cpassword" required>
									</div>
								    
									</div>

									
								<div class="row uniform">
									<div class="3u 12u$(small)">
										<input type="submit" value="Submit" name="submit" class="special" /></li>
									</div>
									<div class="3u 12u$(small)">
										<input type="reset" value="Reset" name="reset"/></li>
									</div>
								</div>
							</center>
							</form>
						</section>

    </div>
    </div>
  </form>
</div>





	</body>
</html>
