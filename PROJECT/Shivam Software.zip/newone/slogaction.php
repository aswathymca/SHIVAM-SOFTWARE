<?php
include("connection.php");
session_start();
$email=$_POST['mail'];
$pass=md5($_POST['password']);
$log="select * from login where Email='$email' and Password='$pass' and status='approved'"; 
$result = $conn->query($log);

$rowid=mysqli_fetch_array($result);


if ($result->num_rows > 0) {
$lid=$rowid['Login_id'];
$usertype=$rowid['User_type'];
    if($usertype==0){
		?>
    
    <script>window.location="test/adminindex.php";</script>
		
	<?php
	$_SESSION["login_id"]=$lid;
	}
	
	else if($usertype==1) {
		$_SESSION["login_id"]=$lid;
	
   echo" <script>
   
 
   window.location='test/userindex.php';</script> ";
	}
	
	
	else if($usertype==2) {
		$_SESSION["login_id"]=$lid;
	
   echo" <script>
   
 
   window.location='test/leader_index.php';</script> ";
	}
	else
		
	{
		$_SESSION["login_id"]=$lid;
	
   echo" <script>
   
 
   alert('something wrong');</script> ";
	}
	
	
	?>
	<?php
	
} 
else {?>
   

    <script>
	 alert("Invalid Email or Password");
	window.location="new_login.php";</script>
	<?php
}

?><?php
$log2="select * from login where Email='admin@gmail.com' and Password='Admin@123' and User_type=0 "; 
$result = $conn->query($log2);
if ($result->num_rows > 0) {
} 

?>


